from lineus import LineUs


class Diagnostics:

    def __init__(self):
        self.my_line_us = LineUs()
        self.my_line_us.connect()


if __name__ == '__main__':
    d = Diagnostics()
    print(d)
